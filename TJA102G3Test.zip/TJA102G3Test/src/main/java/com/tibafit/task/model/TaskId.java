package com.tibafit.task.model;

public class TaskId {

	private Integer taskId;
	private String taskIcon;

}
