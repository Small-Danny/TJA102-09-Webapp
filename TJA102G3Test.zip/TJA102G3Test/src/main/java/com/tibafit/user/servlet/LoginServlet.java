package com.tibafit.user.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.tibafit.user.dao.UserDaoImpl;
import com.tibafit.user.model.User;
import com.tibafit.util.JedisUtil;
import com.tibafit.util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;

	public void init() {
		userDao = new UserDaoImpl();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 設定 request 和 response 的編碼與格式
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json;charset=UTF-8");

		Gson gson = new Gson();

		try {
			// 從Request Body 讀取 JSON 並轉成 Map，因為原本的User物件沒有code屬性
			BufferedReader reader = req.getReader();
			String json = reader.lines().collect(Collectors.joining());
			Map<String, String> loingData = gson.fromJson(json, Map.class);

			String email = loingData.get("email");
			String password = loingData.get("password");
			//查詢email
			User user =userDao.findByEmail(email);
			//驗證使用者是否存在，以及密碼是否正確
			 if (user != null && user.getPassword().equals(password)) {
				 //登入成功，建立session把它存進去
				 HttpSession session =req.getSession();
				 session.setAttribute("userEmail", user.getEmail());
				 //回傳成功訊息
				 resp.getWriter().write("{\"success\": true}");
			 }else {
				 resp.getWriter().write("{\"success\": false, \"message\": \"帳號或密碼錯誤\"}");
			 }

		} catch (Exception e) {
			e.printStackTrace();
			resp.getWriter().write("{\"success\": false, \"message\": \"發生未知錯誤，請聯絡客服\"}");
		}
	}
}