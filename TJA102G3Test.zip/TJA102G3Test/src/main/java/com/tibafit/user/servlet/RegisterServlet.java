package com.tibafit.user.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.tibafit.user.dao.UserDaoImpl;
import com.tibafit.user.model.User;
import com.tibafit.util.JedisUtil;
import com.tibafit.util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;

	public void init() {
		userDao = new UserDaoImpl();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 設定 request 和 response 的編碼與格式
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json;charset=UTF-8");

		Gson gson = new Gson();
		JedisPool jedisPool = JedisUtil.getJedisPool();

		try {
			// 從Request Body 讀取 JSON 並轉成 Map，因為原本的User物件沒有code屬性
			BufferedReader reader = req.getReader();
			String json = reader.lines().collect(Collectors.joining());
			Map<String, String> requestMap = gson.fromJson(json, Map.class);

			String email = requestMap.get("email");
			String password = requestMap.get("password");
			String name = requestMap.get("name");
			String userCode = requestMap.get("code"); // 使用者輸入的驗證碼

//			核心邏輯第一道，是否有獲取驗證碼
	        if (userCode == null || userCode.trim().isEmpty()) {
	            resp.getWriter().write("{\"success\": false, \"message\": \"請輸入電子郵件驗證碼\"}");
	            return;
	        }
			
			
			// 核心邏輯第二道：把Email存在性檢查，這樣才不會導致驗證碼亂填且發信跑去按註冊跳驗證碼過期提示
			User existingUser = userDao.findByEmail(email);
			if (existingUser != null) {
				resp.getWriter().write("{\"success\": false, \"message\": \"這個 Email 已經被註冊了\"}");
				return; // 驗證失敗，中斷程式
			}
			// 姓名欄位的後端驗證
			String nameError = ValidationUtil.validateName(name);
			if (nameError != null) {
				resp.getWriter().write("{\"success\": false, \"message\": \"" + nameError + "\"}");
				return;
			}
			// 從Redis查詢正確的驗證碼
			String correctCode;
			try (Jedis jedis = jedisPool.getResource()) {
				correctCode = jedis.get(email); // 用 email 當 key 取出 code
			}

			// 比對驗證碼
			if (correctCode == null) {
				resp.getWriter().write("{\"success\": false, \"message\": \"驗證碼已過期，請重新發送\"}");
				return;
			}

			if (!correctCode.equals(userCode)) {
				resp.getWriter().write("{\"success\": false, \"message\": \"驗證碼錯誤\"}");
				return;
			}

			// 建立User物件並存入資料庫
			User newUser = new User();
			newUser.setName(name);
			newUser.setEmail(email);
			newUser.setPassword(password); // 注意：實務上密碼要加密

			// 補上後端才能決定的預設值
			newUser.setAccountStatus(1); // 1 代表「啟用」
			newUser.setForgotPasswordURL("");

			userDao.addUser(newUser);

			// 刪除 Redis 的驗證碼，避免重複使用
			try (Jedis jedis = jedisPool.getResource()) {
				jedis.del(email);
			}

			// 回傳成功訊息
			resp.getWriter().write("{\"success\": true}");

		} catch (Exception e) {
			e.printStackTrace();
			resp.getWriter().write("{\"success\": false, \"message\": \"發生未知錯誤，請聯絡客服\"}");
		}
	}
}