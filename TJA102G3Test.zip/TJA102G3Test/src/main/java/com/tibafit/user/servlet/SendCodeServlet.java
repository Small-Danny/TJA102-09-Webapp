package com.tibafit.user.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.tibafit.user.dao.UserDao;
import com.tibafit.user.dao.UserDaoImpl;
import com.tibafit.user.model.User;
import com.tibafit.util.JedisUtil;
import com.tibafit.util.MailService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@WebServlet("/SendCodeServlet")
public class SendCodeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDao userDao;
    private MailService mailService;
    private JedisPool jedisPool;

    @Override
    public void init() throws ServletException {
        userDao = new UserDaoImpl();
        mailService = new MailService();
        jedisPool = JedisUtil.getJedisPool();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");

        Gson gson = new Gson();

        // 1. 從前端請求中讀取 Email
        BufferedReader reader = request.getReader();
        String json = reader.lines().collect(Collectors.joining());
        Map<String, String> requestMap = gson.fromJson(json, Map.class);
        String email = requestMap.get("email");

        // 2. 檢查 Email 是否已被註冊
        User existingUser = userDao.findByEmail(email);
        if (existingUser != null) {
            response.getWriter().write("{\"success\": false, \"message\": \"此信箱已被註冊\"}");
            return;
        }

        // 3. 產生驗證碼，並存入 Redis
        int randomCode = (int)(Math.random() * 900000) + 100000;
        String authCode = String.valueOf(randomCode);

        try (Jedis jedis = jedisPool.getResource()) {
            // 將 'email:驗證碼' 存入 Redis，並設定 5 分鐘後自動過期
            jedis.setex(email, 300, authCode); 
        }

        // 4. 寄送驗證信
        String subject = "TibaFit 會員註冊驗證信";
        String messageText = "您好！您的 TibaFit 註冊驗證碼是：" + authCode + "，有效時間為 5 分鐘。";
        mailService.sendMail(email, subject, messageText);

        // 5. 回傳成功訊息
        response.getWriter().write("{\"success\": true}");
    }
}