package com.tibafit.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {
	// 建立Session工廠
	private static final SessionFactory seesionFactory = buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		// 管理設定檔

		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
		try {
			// 透過 registry 建立 SessionFactory
			return new MetadataSources(registry).buildMetadata().buildSessionFactory();
		} catch (Exception e) {
			// 建立失敗，registry 並拋出例外
			StandardServiceRegistryBuilder.destroy(registry);
			e.printStackTrace();
			throw new ExceptionInInitializerError(e);
		}
	}

	public static SessionFactory getSessionFactory() {
		return seesionFactory;

	}

	public static void shutdown() {
		getSessionFactory().close();
	}

}
