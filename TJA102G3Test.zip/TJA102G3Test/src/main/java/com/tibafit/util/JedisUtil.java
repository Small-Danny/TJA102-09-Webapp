package com.tibafit.util;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class JedisUtil {
	private static JedisPool pool = null;

	// 私有建構子，防止外部 new 物件
	private JedisUtil() {
	}

	// 靜態方法，用來取得唯一的 JedisPool 物件
	public static JedisPool getJedisPool() {
		// Double-checked locking for thread safety
		if (pool == null) {
			synchronized (JedisUtil.class) {
				if (pool == null) {
					JedisPoolConfig config = new JedisPoolConfig();
					config.setMaxTotal(8); // 最大連線數
					config.setMaxIdle(8); // 最大閒置連線數
					config.setMaxWait(java.time.Duration.ofMillis(10000)); // 等待連線的最大時間 (毫秒)

					// Redis 伺服器在哪裡？
					// 先本地"localhost"
					// Redis 伺服器有密碼，需要加上密碼
					pool = new JedisPool(config, "localhost", 6379);
				}
			}
		}
		return pool;
	}

	// 在應用程式關閉時，呼叫此方法來關閉連線池
	public static void shutdownJedisPool() {
		if (pool != null) {
			pool.destroy();
		}
	}
}